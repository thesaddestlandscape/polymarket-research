# Decision log — BTC 5m barato

| Fecha UTC | Decisión | Evidencia/estado | Próximo paso | Reapertura |
|---|---|---|---|---|
| 2026-10-16 07:40Z | Mantener V4 congelada; no declarar rentabilidad validada | 43 señales, 17 ejecutables, +€8,36 y EV comunicado +€0,21/€; 4/10 gates; concentración 180% en un día y alerta drift. Pendiente reproducir. | Seguir forward sin cambiar reglas. | Solo nueva versión experimental; baseline no cambia. |
| 2026-10-16 07:40Z | V7 no señal: primero diagnóstico ligero, no replay masivo | Cero eventos BTC registrados desde 13-Oct pese a discovery positivo. Causa desconocida. | Encontrar primera etapa donde count=0. | Reprocess solo si el diagnóstico lo justifica. |
| 2026-10-16 07:40Z | Recuperar `cosechar al abrir` A/B | Procesó solo 05–06-Oct y no produjo informe; trabajo incompleto. | Hallar script/checkpoint; reanudar idempotente fuera 06–09Z. | No repetir días completos si ya están verificados. |
| 2026-10-16 07:40Z | Fase 2 «lo invisible» depende de A/B | Aún no inició. | Preparar consultas read-only; ejecutar tras A/B salvo plan no contaminante. | Reordenar solo con decisión del chief. |
| 2026-10-16 07:40Z | FV V4 sigue exploratoria | Solo dos días cronológicos; n y métricas comunicadas pendientes de auditoría. | Mantener forward congelado; revisar al cumplir ≥5 días válidos. | Maker FV 4/4b solo con nueva versión y revisión independiente. |
| 2026-10-16 07:40Z | Agente 5 debe diseccionar, mejorar y superar wallets | La rentabilidad wallet puede mezclar dirección, pares, maker, fees y otros universos. Copy-trading tardío no sirve. | Ledger wallet y mecanismo; política propia; holdout. | Cualquier comparación requiere baseline OOS. |
| 2026-10-16 07:40Z | Objetivo familiar = €200k netos/año mediante suma de subestrategias | Familia validada €0; discovery V6+V7 ~€60k/año no validado. | Risk-economics produce plan de contribución y gap con medios existentes, sin doble conteo. | Revisar al aparecer evidencia/gates nuevos. |
| 2026-10-16 07:40Z | Cierre de vía cancelación durante taker-delay | F1 histórico comunicó rechazo explícito de cancelación de órdenes retenidas; no repetir orden real. | Mantener cerrada y documentar evidencia. | Solo evidencia técnica nueva que cambie el comportamiento observado. |

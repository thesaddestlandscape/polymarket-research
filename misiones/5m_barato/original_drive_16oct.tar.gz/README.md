# Agentes Claude Code — BTC 5m barato (rediseño 16-Oct-2026)

Paquete de 10 subagentes para investigar, construir y validar la familia **Polymarket BTC 5m barato**. El objetivo económico es una cartera de subestrategias complementarias hacia €200.000 netos anuales agregados, usando medios existentes y sin doble conteo. A 16-Oct 07:40Z la contribución validada es €0; la estimación de ~€60k/año entre V6 y V7 es discovery-only.

## Cambios clave del rediseño

- Prioridades reales al 16-Oct: recuperar `cosechar al abrir` A/B (se interrumpió después del 05–06-Oct y no produjo informe), diagnosticar el cero de V7 mediante una consulta barata, preparar conciliación F2 del 17-Oct y mantener los forwards V4/FV V4 congelados.
- Todo análisis largo requiere checkpoint, manifest, resume idempotente, coverage y reporte final. Sin informe = no terminado.
- Heavy run de `cosechar al abrir` debe realizarse fuera de 06:00–09:00Z.
- El agente de wallets (agente 5) no copia operaciones: reconstruye estrategias, atribuye PnL, encuentra debilidades y especifica mejoras propias para intentar superar a los ganadores en OOS.
- El agente de riesgo/economía trabaja activamente en el gap de €200k a través de la suma de subestrategias BTC 5m barato, overlap, capital/capacidad y roadmap con medios existentes; no se limita a decir que no está validado.
- V4 y datos raw quedan inmutables. No se autorizan nuevas órdenes reales, secretos ni gastos de infraestructura.

## Contenido

- `CLAUDE.md`: instrucciones maestras y estado.
- `.claude/agents/cheap5m-chief.md`: coordinación/prioridades.
- `.claude/agents/01-repo-auditor.md`: auditoría de repositorio, jobs interrumpidos y baselines.
- `.claude/agents/02-market-data-engineer.md`: feeds, calidad de datos, timestamps y diagnóstico de señales ausentes.
- `.claude/agents/03-event-causality-analyst.md`: precursor de cambio de bid 15m/ask obsoleto y causalidad.
- `.claude/agents/04-wallet-intelligence-analyst.md`: agente 5; disección de wallets y diseño para mejorar/superar su mecanismo, nunca copiar fills.
- `.claude/agents/05-alpha-researcher.md`: hipótesis, subcategorías y valor incremental.
- `.claude/agents/06-execution-engineer.md`: único implementador de código experimental y jobs reanudables.
- `.claude/agents/07-statistical-validator.md`: validación independiente.
- `.claude/agents/08-risk-economics.md`: hoja de ruta activa hacia €200k netos por suma no solapada.
- `.claude/agents/09-red-team-auditor.md`: auditoría adversarial.
- `docs/ESTADO_INVESTIGACION_2026-10-16.md`: estado actual y cifras comunicadas.
- `docs/PLAN_EJECUCION_PRIORIDADES.md`: secuencia P0–P7.
- `docs/REGISTRO_HIPOTESIS.md`: estado inicial de mecanismos.
- `docs/DECISION_LOG.md`: decisiones fechadas y causas.
- `docs/FLUJO_DE_TRABAJO.md`: protocolos, delegación y validación.
- `docs/PROMPT_INICIAL.md`: prompt listo para la primera sesión.
- `docs/INICIO_RAPIDO.md`: guía de instalación y primera tarea.

## Instalación

1. Descomprime el paquete en la raíz del repo de investigación. Si ya tienes `CLAUDE.md`, integra las nuevas reglas sin sobrescribir información local importante.
2. Revisa las rutas y los nombres de scripts antes de ejecutar cualquier comando.
3. Abre Claude Code desde esa raíz. Los agentes de proyecto viven en `.claude/agents/*.md`; si acabas de instalarlos y no aparecen, inicia una sesión nueva.
4. Copia `docs/PROMPT_INICIAL.md` para la primera sesión.

## Restricciones

Los agentes de investigación son read-only. Solo `cheap5m-execution-engineer` puede editar código experimental y nunca modifica V4 ni despliega. Los prompts no reemplazan permisos del sistema: mantén aprobaciones activas. Nunca leer `.env` ni exponer credenciales. Solo shadow/dry-run; sin órdenes reales ni gastos.

Especificación de subagentes de Claude Code: https://code.claude.com/docs/en/sub-agents

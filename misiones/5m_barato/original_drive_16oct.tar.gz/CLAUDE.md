# 5M BARATO — INSTRUCCIONES MAESTRAS Y ESTADO DE INVESTIGACIÓN

**Corte de estado:** 16-Oct-2026 07:40Z. Las cifras son comunicadas por el investigador; deben reproducirse desde los artefactos originales antes de considerarse validadas. Las instrucciones de prioridad se actualizan a partir del parte de 16-Oct.

## 1. Misión única

Investigar, diseñar, implementar en modo seguro y validar las subestrategias de la familia **Polymarket BTC 5m barato**. La meta familiar es desarrollar una cartera de subestrategias complementarias que aspire a **200.000 € netos anuales en conjunto**, usando en primer lugar los datos, código, feeds, tiempo de cómputo e infraestructura que ya están disponibles.

El agente económico no debe limitarse a responder que la cifra no está validada: debe trabajar hacia ella, cuantificar el gap, encontrar contribuciones plausibles por subestrategia y proponer un plan de investigación que maximice la probabilidad de cerrar el gap con los medios existentes. A la vez, no debe inventar rentabilidad, relajar gates, sobreajustar, escalar stake a ciegas ni convertir estimaciones de descubrimiento en previsiones.

**Beneficio anual validado actual: 0 €.** La cifra objetivo es un objetivo de diseño y priorización, no una cuota que sesgue los experimentos.

La estrategia dedicada a BTC 15m permanece independiente. Puede aportar variables de referencia para 5m, pero no se mezclan universos ni resultados sin demostrar un mecanismo y una comparación correcta.

## 2. Principios no negociables

1. **Solo shadow/dry-run para nuevas pruebas.** F1 del 15-Oct incluyó pruebas reales históricas; no repetir órdenes reales. Antes de tocar el proceso F2, verificar su modo efectivo desde configuración/logs. No cambiar modo ni activar un sender live.
2. **Sin gastos sin autorización.** No contratar VPS, proveedores, datos ni servicios. Priorizar instrumentos, optimizaciones y cómputo ya disponible.
3. **No leer secretos.** Nunca abrir, imprimir, copiar o transmitir `.env`, claves, API secrets, tokens de autenticación, seed phrases o claves privadas. No usar endpoints privados de trading ni firmar transacciones.
4. **Baselines congelados.** No modificar V4 `77a75859ae5cf22e`, sus parámetros, resultados históricos ni datasets raw. Nuevos mecanismos van en rama/directorio experimental propio.
5. **Agente 5 = ingeniería inversa, no copia.** Debe diseccionar la estrategia completa de las wallets ganadoras, encontrar la fuente de su PnL, sus limitaciones y los mecanismos generalizables, y proponer cómo adaptar y mejorar el código propio para intentar superarlas. No generar señales copiando fills observados tarde.
6. **No alpha por narrativa.** PnL de una wallet, un hit rate alto, un EV in-sample, un resultado de dos días o un techo teórico no bastan.
7. **Trazabilidad.** Cada cifra necesita fuente, periodo, universo, denominador, fórmula, moneda, costes y artefacto. Los datos ausentes son `missing`, no cero. No reproducido = no verificado.
8. **No look-ahead.** Toda decisión debe usar solo información observable en el timestamp de decisión. Separar exchange event, feed receive, decision, send, arrival, fill/quote disappearance y chain settlement.
9. **Contabilidad completa.** Incluir señales descartadas, fills parciales, órdenes sin fill, posiciones residuales, pérdidas, ventanas sin oportunidad y exposición simultánea. No contar solo pares o trades ganadores.
10. **Validación cronológica.** Separar descubrimiento, calibración, OOS, forward shadow/dry-run y decisiones de despliegue. Cualquier cambio después de ver resultados crea nueva versión y requiere periodo confirmatorio.
11. **Análisis largos recuperables.** Todo trabajo largo necesita manifest, checkpoint durable, claves idempotentes, log, cobertura por fecha/mercado, resumen parcial e informe final. Una sesión que muere sin informe queda `PARTIAL/FAILED`, nunca «terminada».
12. **Un único trabajo intensivo a la vez.** Evitar competencia de I/O entre agentes. Heavy run `cosechar al abrir` solo fuera de 06:00–09:00Z. Dentro de esa franja se permiten diagnósticos ligeros, auditoría y preparación.
13. **El objetivo de 200k orienta el portafolio.** Diseñar la suma de subestrategias con exposición no duplicada y contribución marginal medible. No presentar €200k como logrado ni alcanzable sin evidencia; tampoco abandonar la búsqueda sin mapear el gap y las palancas plausibles.
14. **Cementerio respetado.** No reabrir una hipótesis refutada cambiándole el nombre. Hace falta mecanismo sustancialmente nuevo, evidencia nueva o error concreto en el test previo.

## 3. Estado actual — 16-Oct-2026 07:40Z

La fuente maestra ampliada es `docs/ESTADO_INVESTIGACION_2026-10-16.md`. Si el resumen contradice los datos/código fuente, registrar la discrepancia y conservar ambas referencias hasta resolverla.

### 3.1 Forward de subestrategias — todas solo observación, ninguna ha pasado gates

- **V4 (v1 corregida; baseline):** OOS desde 06-Oct hasta 15-Oct; 43 señales, 17 ejecutables, +€8,36, EV comunicado +€0,21/€. Nueve días; 4/10 gates. Un día aporta el 180 % del PnL. Los tres días más recientes están por debajo del 50 % del EV previo: alerta `DRIFT`. Frágil, aún no validada. Mantener forward congelado.
- **V2:** variante con todas las señales, hasta tres por mercado. Desde 12-Oct: cinco mercados, −€2,57, EV comunicado −€0,18; 0/7 gates. Peor que V4 en el periodo común según el parte; auditar la diferencia comunicada.
- **V3/V3a:** V4 con filtro Binance de cinco segundos. Desde 12-Oct: un mercado, −€2,12; 0/7 gates. Muestra insuficiente.
- **V5 `ORIGEN15M`:** desde 14-Oct, una señal y cero ejecuciones; 3/11 gates. Muestra insuficiente.
- **V6 `FOK_VUELO_BTC`:** desde 14-Oct, una ejecución y −€2,12; 0/7 gates. Discovery comunicado ~€30k/año, solo si se valida; descubrir por qué en discovery ganaban las señales “visibles”.
- **V7 `DISPARO15M_BTC`:** discovery comunicado de 8/8 días positivos, EV +1,99 y estimación exploratoria de ~€28–37k/año. Forward desde 14-Oct: cero ejecuciones; no hay eventos BTC registrados desde 13-Oct. Diagnosticar con una consulta ligera si hay sequía genuina, cambio de régimen o fallo en feed/filtros/registro/pipeline.

**Contribución anual validada de toda la familia: 0 €.** Estimación de discovery combinada V6+V7 ~€60k/año, sin validar y potencialmente no aditiva por solapamientos, capital o condiciones compartidas.

### 3.2 FV V4 — candidata nueva más prometedora, aún exploratoria

Dos días cronológicos comunicados: R² del movimiento de mid a 3 s de 0,28/0,29; ΔBrier frente al mid −0,003 en ambos días; como taker con margen 0,05, n=457 y EV +€0,095/€, resultados diarios +€0,049 y +€0,142. Auditar unidades, denominadores, costes, definición de ΔBrier, calendario exacto y separación discovery/OOS. Mantener el forward congelado. Si alcanza al menos cinco días cronológicos válidos y la auditoría es favorable, congelar una especificación separada para maker FV 4/4b y someterla a revisión independiente; cinco días no validan por sí solos el alpha.

### 3.3 Wallet intelligence: objetivo de mejorar y superar, no copiar

- Compras BTC por bucket: EV comunicado +€0,044/€ para precios <0,10 y +€0,082/€ para precios 0,10–0,20; reproducir fórmula y disponibilidad temporal.
- Wallets seleccionadas por rendimiento en 05–09-Oct supuestamente tuvieron +€0,057/€ en 10–14-Oct, IC90 por días +€0,022..+€0,087. Falta recuperar el placebo truncado (`−0,...`).
- `mo-money`: +$10,4k en diez días, según el parte; pares −$15,9k y dirección +$26,3k, por lo que no debe clasificarse como simple pair-harvester sin más evidencia. También está truncada la frase de su hit rate de primera pata barata.
- Agent 5 debe reconstruir estrategia, inventario, decisión, selección, timing, costes y fuente de beneficio; identificar fortalezas y límites; traducir mecanismos a una política propia que intentemos mejorar y superar en replay emparejado OOS. Nunca copiar fills tardíos. La fase 2 «lo invisible» depende del informe de `cosechar al abrir` A/B, salvo que el chief documente cómo ejecutarla en paralelo sin contaminar resultados.

### 3.4 Trabajos interrumpidos

- `cosechar al abrir` A/B: análisis A (5m general) y B (5m barato con defensa 15m) murió con la sesión tras procesar solo 05–06-Oct y no dejó informe. No asumir terminación. Buscar script, stdout/stderr, artefactos, checkpoint y claves procesadas. Reanudar idempotentemente desde el último dato válido. Ejecutar el cómputo pesado fuera de 06:00–09:00Z. Comando citado parcialmente: `nice -n 19 ionice -c3 python3 ...`; recuperar ruta exacta, no adivinarla.
- Fase 2 «lo invisible» de wallets baratas: no arrancó y depende del anterior. Crear primero especificación de datos y consultas read-only; ejecutar fase completa después de A/B, salvo decisión de no contaminación.

### 3.5 Infraestructura y F2

- F1 (15-Oct): prueba real histórica informó taker-in-book ~50 ms y cancelación dentro del taker-delay imposible. No repetir órdenes reales; vía de cancelar órdenes retenidas cerrada salvo evidencia nueva.
- F2 (desde 16-Oct): V4 y V7 en proceso separado, según reporte. Verificar modo efectivo shadow/dry-run sin cambiarlo. Tres pasadas de code review comunicadas. Primera conciliación con los «vigías» prevista para 17-Oct. Criterios F2→F3 congelados: recuperar del diseño original, no redefinir. Medición decision→send con firmador separado pendiente en referencias 07:30 y 07:45; aclarar la semántica exacta desde logs. No enviar órdenes.

### 3.6 Cementerio: no reabrir sin evidencia nueva

- Pares 5m maker OOS −0,050.
- Maker un solo lado.
- Copiar makers ganadores (no persiste).
- Copiar tomadoras persistentes.
- FV v1–v3 (no batían al mid).
- `LOWLOW-PAIR` indiscriminado.
- `BTC5M-FV-LONGSHOT` anterior tal como fue probado.
- Entrada con retraso deliberado.
- Vender un bid15 rancio.
- Cancelación de órdenes retenidas durante taker-delay.
- Caja de dos patas a 250–400 ms (−35/−179 $ comunicados; auditar unidades si se usa).

### 3.7 Sin empezar / baja prioridad

Caja altcoin (10 días, cifras comunicadas: XRP +$703, DOGE +$203, BNB +$53, BTC −$7.553, ETH −$1.824, SOL −$859), cajas anidadas con 4h, caja maker de dos patas y maker FV 4/4b. Priorizar estas líneas solo después de P0–P4; maker FV queda condicionado a FV V4 ≥5 días cronológicos válidos y revisión.

## 4. Prioridad operativa actual

1. **P0 — Recuperar `cosechar al abrir` A/B** con checkpoints y reporte, fuera de 06:00–09:00Z. Verificar cobertura antes de reanudar; solo 05–06-Oct se han comunicado como procesados.
2. **P1 — Diagnóstico barato de V7 sin señales BTC:** encontrar primer paso del pipeline en el que el conteo cae a cero: datos, feed, reloj, parser, filtros, registro o sequía/regimen.
3. **P2 — Preparar conciliación F2 del 17-Oct:** verificar modo shadow, recuperar criterios congelados y preparar comparación contra vigías sin órdenes reales.
4. **P3 — Mantener forward congelados de V4 y FV V4:** auditoría de métricas, sin ajustar sus reglas; observar drift.
5. **P4 — Wallet strategy dissection / fase 2 invisible:** después de A/B, salvo plan read-only independiente que no contamine universo o conclusiones.
6. **P5 — Si FV V4 acumula ≥5 días válidos:** especificación congelada maker FV 4/4b, revisión independiente y forward separado.
7. **P6 — Cartera de subestrategias y meta económica:** risk-economics modela contribuciones independientes, solapamientos y gap a 200k con medios existentes.
8. **P7 — Otras hipótesis:** altcoin boxes, anidados 4h y maker box solo tras resolver prioridades anteriores.

## 5. Agentes y autoridad

- `cheap5m-chief`: priorización, dependencias, decisión y un único job pesado.
- `cheap5m-repo-auditor`: solo lectura; fuentes, baseline, procesos y continuidad.
- `cheap5m-market-data-engineer`: calidad y contrato de datos; diagnósticos baratos.
- `cheap5m-event-causality-analyst`: precursor 15m, ask obsoleto, cronología.
- `cheap5m-wallet-intelligence-analyst` (agente 5): ingeniería inversa de wallets ganadoras para mejorar/adaptar nuestro código y superar benchmarks, no copiar fills.
- `cheap5m-alpha-researcher`: diseñar/ordenar hipótesis y valor de la información.
- `cheap5m-execution-engineer`: único implementador de código experimental y de reanudación; no modifica V4 ni modo live.
- `cheap5m-statistical-validator`: validación independiente.
- `cheap5m-risk-economics`: plan económico de portafolio para alcanzar 200k mediante la suma de subestrategias de 5m barato, dentro de recursos existentes, con contabilidad rigurosa.
- `cheap5m-red-team-auditor`: intento independiente de refutar conclusiones.

## 6. Etiquetas permitidas

`REJECTED`, `DATA_BLOCKED`, `EXPLORATORY`, `PROMISING`, `DRY_RUN_VALIDATED`. La etiqueta `DRY_RUN_VALIDATED` no autoriza trading live. Ningún agente puede declarar 200k alcanzables sin modelo de contribución, capacidad, capital, solapamiento, incertidumbre y pruebas empíricas.
